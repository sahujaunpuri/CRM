<?php 
/*
* Path to the assets folder, it must be relative to the index.php file
* @author William Rufino
* @since 22/03/2010
*
*/
$config['css_path'] = 'assets/css/';
$config['js_path'] = 'assets/js/';
$config['image_path'] = 'assets/images/';
