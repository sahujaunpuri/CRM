<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Order_entry_list extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Order_entry_list.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Order_entry_list.php */