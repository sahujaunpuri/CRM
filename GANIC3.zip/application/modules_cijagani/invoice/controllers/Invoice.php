<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Invoice extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Invoice.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Invoice.php */