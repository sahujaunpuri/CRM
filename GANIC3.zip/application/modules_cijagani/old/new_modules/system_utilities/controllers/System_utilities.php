<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class System_utilities extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file System_utilities.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/System_utilities.php */