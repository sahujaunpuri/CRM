<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Quotation_list extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Quotation_list.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Quotation_list.php */