<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Company_profile extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Company_profile.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Company_profile.php */